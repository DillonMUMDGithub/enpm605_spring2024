# import player

class Item:
    
    def __init__(self,name,description: str,item_type: str):
        self.name = name
        self.description = description
        self.item_type = item_type
 
    
    
# if __name__ == "__main__":
#     Ar1 = Item(name="Ar1",description = "the first arrow",item_type = "Arrow")
#     print(Ar1.item_type)
#     Ar1.pickup(Ar1)
        